﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppStudio.Data
{
    public enum FontSizes
    {
        Small,
        Normal,
        Big
    }
}
